const mysql = require('mysql2/promise');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
let pool = null;

const dbConfig = {
  host: process.env.CENTRAL_DB_HOST || 'lynxlocal.mysql.uhserver.com',
  user: process.env.CENTRAL_DB_USER || 'lynxlocal_root',
  password: process.env.CENTRAL_DB_PASS || 'lynx@2022',
  database: process.env.CENTRAL_DB_NAME || 'lynxlocal',
  port: 3306,
  charset: 'utf8mb4',
  waitForConnections: true,
  connectionLimit: 20,           // PERF: aumentado de 10→20 para suportar usuários simultâneos
  queueLimit: 100,               // PERF: fila ampliada para absorver picos de requisição
  enableKeepAlive: true,
  keepAliveInitialDelay: 10000,  // PERF: ping keepalive mais frequente para conexão remota
  connectTimeout: 15000,         // 15s timeout de conexão (rede remota pode ser lenta)
  idleTimeout: 120000            // 2 min — evita fechamento prematuro em workloads intermitentes
};

const { AsyncLocalStorage } = require('async_hooks');
const asyncLocalStorage = new AsyncLocalStorage();

const pools = new Map(); // Store pools by dbName
let defaultPool = null;  // Keep track of the default/initial pool

// Initialize the pool
// Initialize the pool (Active pool logic refined)
const initPool = (config) => {
  try {
    const dbName = config.database;

    // Check if pool already exists for this DB
    if (pools.has(dbName)) {
      console.log(`[DB] Pool already exists for ${dbName}. Re-using.`);
      // Ensure default pool is set if this is the first one or explicitly requested?
      // For now, if we are "initing", we assume this might be the default for background tasks 
      // OR just adding to the roster.
      if (!defaultPool) defaultPool = pools.get(dbName);
      return true;
    }

    // Merge with defaults
    const newConfig = { ...dbConfig, ...config };

    const newPool = mysql.createPool(newConfig);
    pools.set(dbName, newPool);

    if (!defaultPool) {
      defaultPool = newPool;
      console.log(`[DB] Default Pool initialized with host: ${newConfig.host}, database: ${newConfig.database}`);
    } else {
      console.log(`[DB] Additional Pool initialized for: ${newConfig.database}`);
    }

    return true;
  } catch (error) {
    console.error('[DB] Failed to initialize pool:', error);
    return false;
  }
};

// Initial startup - single call only
initPool(dbConfig);

// Helper to get current pool based on context
const getPool = () => {
  const store = asyncLocalStorage.getStore();
  if (store && store.dbName && pools.has(store.dbName)) {
    return pools.get(store.dbName);
  }
  return defaultPool;
};

const verifiedTablesCache = new Map();

const execute = async (sql, params, retries = 1) => {
  const pool = getPool();
  if (!pool) {
    throw new Error('Database pool not initialized.');
  }

  const SLOW_QUERY_MS = parseInt(process.env.SLOW_QUERY_MS) || 200;
  const cleanSql = sql.replace(/\s+/g, ' ').trim();

  // --- IdMatriz Global Interceptor ---
  const store = asyncLocalStorage.getStore();
  if (store && store.dbName && store.tenantId) {
    // Basic regex to find table name in INSERT INTO or UPDATE
    const match = cleanSql.match(/^(?:INSERT\s+INTO|UPDATE)\s+`?([a-zA-Z0-9_]+)`?/i);
    if (match) {
      const tableName = match[1];
      const cacheKey = store.dbName + '_' + tableName;
      
      if (!verifiedTablesCache.has(cacheKey)) {
        try {
          const [cols] = await pool.execute(`SHOW COLUMNS FROM \`${tableName}\` LIKE 'IdMatriz'`);
          if (cols.length === 0) {
            console.log(`[DB] Injecting IdMatriz into table: ${tableName} for tenant ${store.tenantId}`);
            await pool.execute(`ALTER TABLE \`${tableName}\` ADD COLUMN IdMatriz INT DEFAULT ${store.tenantId}`);
          }
          verifiedTablesCache.set(cacheKey, true);
        } catch (e) {
          console.error(`[DB] Failed to verify/inject IdMatriz for table ${tableName}:`, e.message);
        }
      }

      // Conforme solicitado, qualquer tabela que receber inclusão de registro ou update 
      // deve ter o IdMatriz preenchido com o ID do banco ativo.
      // O update assíncrono abaixo garante que a linha recém-inserida receba o IdMatriz caso tenha vindo nula,
      // e também corrige eventuais registros antigos da tabela que estejam com NULL.
      if (cleanSql.toUpperCase().startsWith('INSERT') || cleanSql.toUpperCase().startsWith('UPDATE')) {
        pool.execute(`UPDATE \`${tableName}\` SET IdMatriz = ${store.tenantId} WHERE IdMatriz IS NULL`)
          .catch(e => console.error(`[DB] Async IdMatriz update failed for ${tableName}:`, e.message));
      }
    }
  }
  // --- End Interceptor ---

  try {
    const start = Date.now();
    const result = await pool.execute(sql, params);
    const duration = Date.now() - start;
    const rowCount = Array.isArray(result[0]) ? result[0].length : (result[0]?.affectedRows || 0);

    const store = asyncLocalStorage.getStore();
    const dbLabel = store?.dbName ? `[${store.dbName}]` : '[DEFAULT]';

    if (duration >= SLOW_QUERY_MS) {
      console.warn(`[DB] ${dbLabel} ⚠️  SLOW QUERY (${duration}ms | rows:${rowCount}): ${cleanSql.substring(0, 300)}`);
    } else if (process.env.DB_VERBOSE === 'true') {
      console.log(`[DB] ${dbLabel} 🟢 OK (${duration}ms) - Rows: ${rowCount}`);
    }
    return result;
  } catch (err) {
    // Retry logic for dropped connections (common in Hostinger/remote MySQL)
    if (retries > 0 && (err.code === 'ECONNRESET' || err.code === 'PROTOCOL_CONNECTION_LOST' || err.code === 'ETIMEDOUT' || err.code === 'EPIPE')) {
        console.warn(`[DB] ⚠️  Connection dropped (${err.code}). Retrying query in 250ms... (${retries} retries left)`);
        await new Promise(r => setTimeout(r, 250));
        return execute(sql, params, retries - 1);
    }

    // --- Auto-Healing Interceptor (Missing Columns) ---
    if (retries > 0 && err.code === 'ER_BAD_FIELD_ERROR') {
      const match = err.sqlMessage.match(/Unknown column '([^']+)'/i);
      if (match) {
        let colName = match[1];
        if (colName.includes('.')) colName = colName.split('.').pop(); // e.g. 't.TagJaExcluida' -> 'TagJaExcluida'
        
        console.log(`[DB-AUTO-SYNC] Unknown column detected: ${colName}. Searching in master DB (lynxlocal)...`);
        try {
          const [colDefs] = await executeOnDefault(
            `SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT 
             FROM INFORMATION_SCHEMA.COLUMNS 
             WHERE TABLE_SCHEMA = DATABASE() AND LOWER(COLUMN_NAME) = LOWER(?)`, [colName]
          );

          if (colDefs.length > 0) {
            // Found in master DB. Match table from query
            let targetTableDef = colDefs.find(def => new RegExp(`\\b${def.TABLE_NAME}\\b`, 'i').test(cleanSql));
            if (!targetTableDef && colDefs.length === 1) targetTableDef = colDefs[0];
            
            if (targetTableDef) {
              console.log(`[DB-AUTO-SYNC] Found ${colName} in master table ${targetTableDef.TABLE_NAME}. Adding to tenant...`);
              const isNull = targetTableDef.IS_NULLABLE === 'YES' ? 'NULL' : 'NOT NULL';
              const defVal = targetTableDef.COLUMN_DEFAULT !== null ? `DEFAULT '${targetTableDef.COLUMN_DEFAULT}'` : '';
              await pool.execute(`ALTER TABLE \`${targetTableDef.TABLE_NAME}\` ADD COLUMN \`${colName}\` ${targetTableDef.COLUMN_TYPE} ${isNull} ${defVal}`);
              console.log(`[DB-AUTO-SYNC] Added ${colName} successfully. Retrying query...`);
              return await execute(sql, params, 1); // Reset retries to handle multiple missing columns
            }
          } else {
            console.log(`[DB-AUTO-SYNC] Column ${colName} NOT found in master DB either. Replacing with NULL in query...`);
            // Replace literal column occurrences with NULL to ignore it safely
            const exactColMatch = match[1]; // e.g. "t.TagJaExcluida"
            const escapedMatch = exactColMatch.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
            const newSql = sql.replace(new RegExp(`\\b${escapedMatch}\\b`, 'gi'), 'NULL');
            
            if (newSql !== sql) {
               console.log(`[DB-AUTO-SYNC] Query rewritten to ignore ${exactColMatch}. Retrying...`);
               return await execute(newSql, params, 1); // Reset retries to handle multiple missing columns
            }
          }
        } catch (syncErr) {
          console.error(`[DB-AUTO-SYNC] Auto-sync failed: ${syncErr.message}`);
        }
      }
    }
    // --- End Auto-Healing ---

    console.error(`[DB] 🔴 ERROR: ${err.message}`);
    console.error(err);
    throw err;
  }
};

// Wrappers for other pool methods to maintain compatibility
const getConnection = async () => {
  const pool = getPool();
  if (!pool) throw new Error('Database pool not initialized.');
  return pool.getConnection();
};

const query = async (...args) => {
  const pool = getPool();
  if (!pool) throw new Error('Database pool not initialized.');
  return pool.query(...args);
};

// Sync methods
const escape = (...args) => { const p = getPool(); return p ? p.escape(...args) : mysql.escape(...args); };
const format = (...args) => { const p = getPool(); return p ? p.format(...args) : mysql.format(...args); };

// Test specific connection config without affecting main pool
const testConnection = async (config) => {
  let tempPool = null;
  try {
    tempPool = mysql.createPool({
      ...config,
      waitForConnections: true,
      connectionLimit: 1,
      queueLimit: 0
    });
    const [rows] = await tempPool.execute('SELECT 1 as val');
    return rows[0].val === 1;
  } catch (error) {
    console.error('[DB] Test connection failed:', error.message);
    throw error;
  } finally {
    if (tempPool) tempPool.end();
  }
};

// Execute always on the default/central pool (ignores tenant context)
const executeOnDefault = async (sql, params, retries = 3) => {
  if (!defaultPool) throw new Error('Default database pool not initialized.');
  const cleanSql = sql.replace(/\s+/g, ' ').trim();
  console.log(`\n[DB] 🔵 EXEC (DEFAULT): ${cleanSql}`);
  try {
    const result = await defaultPool.execute(sql, params);
    const rowCount = Array.isArray(result[0]) ? result[0].length : (result[0]?.affectedRows || 0);
    console.log(`[DB] [DEFAULT] 🟢 OK - Rows: ${rowCount}`);
    return result;
  } catch (err) {
    if (retries > 0 && (err.code === 'ECONNRESET' || err.code === 'PROTOCOL_CONNECTION_LOST' || err.code === 'ETIMEDOUT' || err.code === 'EPIPE')) {
        console.warn(`[DB] ⚠️  Connection dropped (${err.code}) on DEFAULT pool. Retrying query in 250ms... (${retries} retries left)`);
        await new Promise(r => setTimeout(r, 250));
        return executeOnDefault(sql, params, retries - 1);
    }
    throw err;
  }
};

module.exports = {
  execute,
  executeOnDefault,
  query,
  getConnection,
  escape,
  format,
  initPool,
  hasPool: (name) => pools.has(name),
  getPoolByName: (name) => pools.get(name) || null,
  testConnection,
  getConfig: () => ({ ...dbConfig }), // Return copy of current config
  asyncLocalStorage // Export for middleware
};
